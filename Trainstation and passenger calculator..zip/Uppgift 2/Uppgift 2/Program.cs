﻿
using System.Runtime.InteropServices.Marshalling;

namespace SJProgram
{
    class Program
    {
        // Variabler som behövs.
        static void Main(string[] args)
        {
           
            int kapacitet=GetKapacitet();
            int stationer=GetStationer();
            
        

//  Första inmatning på tågets kapacitet
static int GetKapacitet()
{
    Console.WriteLine("Tågets kapacitet: ");
    int kapacitet = int.Parse(Console.ReadLine());
    if(kapacitet < 1 || kapacitet > 40)
    {
        Console.WriteLine("Vänligen ange kapacitet mellan 1 till 40. ");
        System.Environment.Exit(0);
    }
    return kapacitet;

}
// Första inmatning på antal stationer.
static int GetStationer()
{
    Console.WriteLine("Hur många stationer(2-10st): ");
    int stationer=int.Parse(Console.ReadLine());
    if(stationer < 2 || stationer > 10)
    {
        Console.WriteLine("Vänligen ange mellan 2 till 10 stationer. ");
        System.Environment.Exit(0);
    }
    return stationer;
}


//Deklaration av variabler
int stiger_av;
int stiger_på;
int stannar;
int summa_paTaget = 0;
int lamna_taget = 0;
int summa_perongen = 0;
int sistaSumma_paTaget = 0;
int sistaSumma_perongen = 0;

//Få input från användaren om hur många som stiger av, på och stannar vid varje station.
//Se så att värdena stämmer inom de givna parametrarna annars ge felmeddelande och avsluta programmet.

for (int cnt = 0; cnt < stationer - 1; cnt++)
{
    Console.WriteLine("Hur många lämnar tåget? ");
    stiger_av=int.Parse(Console.ReadLine());
    lamna_taget = lamna_taget + stiger_av;
    if (stiger_av < 0 || stiger_av > 40)
    {
        Console.WriteLine("Inte mindre än 0 eller mer än 40 kan lämna tåget. ");
        System.Environment.Exit(0);
    }

    Console.WriteLine("Hur många stiger på tåget? ");
    stiger_på=int.Parse(Console.ReadLine());
    summa_paTaget = summa_paTaget + stiger_på;
    if(stiger_på < 0 || stiger_på > 40)
    {
        Console.WriteLine("Inte mindre än 0 eller mer än 40 kan stiga på tåget. ");
        System.Environment.Exit(0);
    }

    Console.WriteLine("Hur många stannar på perongen? ");
    stannar=int.Parse(Console.ReadLine());
    if(stannar < 0 || stannar > 40)
    {
        Console.WriteLine("Inte mindre än 0 eller mer än 40 kan stanna kvar på perongen. ");
        System.Environment.Exit(0);
    
    }
//Här blev jag tvungen att göra en separat interation av den sista stationen för att kunna se att allt stämde när tåget anlänt till sista station.  
} 
 Console.WriteLine("Hur många lämnar tåget? ");
    stiger_av=int.Parse(Console.ReadLine());
    lamna_taget = lamna_taget + stiger_av;
    if (stiger_av < 0 || stiger_av > 40)
    {
        Console.WriteLine("Inte mindre än 0 eller mer än 40 kan lämna tåget. ");
        System.Environment.Exit(0);
    }

    Console.WriteLine("Hur många stiger på tåget? ");
    stiger_på=int.Parse(Console.ReadLine());
    sistaSumma_paTaget = summa_paTaget + stiger_på;
    if(stiger_på < 0 || stiger_på > 40)
    {
        Console.WriteLine("Inte mindre än 0 eller mer än 40 kan stiga på tåget. ");
        System.Environment.Exit(0);
    }

    Console.WriteLine("Hur många stannar på perongen? ");
    stannar=int.Parse(Console.ReadLine());
    sistaSumma_perongen = summa_perongen + stannar;
    if(stannar < 0 || stannar > 40)
    {
        Console.WriteLine("Inte mindre än 0 eller mer än 40 kan stanna kvar på perongen. ");
        System.Environment.Exit(0);
    
    }
    
//Se om utmatning är möjligt genom att se att det är ingen kvar på tåget när det anlänt till slutstation.
    
int kvarPaTaget = summa_paTaget - lamna_taget;
if (kvarPaTaget == 0 && sistaSumma_perongen == 0)
{
    Console.WriteLine("Möjligt");
}
else if (kvarPaTaget < 0 || kvarPaTaget > 1 || sistaSumma_paTaget > 0 || sistaSumma_perongen != 0)
{
    Console.WriteLine("Omöjligt");
}




}
}
}

