﻿
using System.Drawing;
using Microsoft.VisualBasic;

namespace BetygSättning
{
    class Program
    {
        static void Main(string[] args)
    {
        
        LäsPoäng();
        
        
        //char[] betyg = new char[6];
        
    }

        
        //Deklarera array och variabler
        static void LäsPoäng()
        {
        
        string[] ämnen = { "Matematik", "Svenska", "Engelska", "Historia", "Fysik" };
        int[] poäng = new int[5];

        //Få poäng av användaren av de ämnen i arrayen och spara detta i poäng.
        Console.WriteLine("Ange dina poäng för ämnet " + ämnen[0] + ":");
        poäng[0] = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Ange dina poäng för ämnet " + ämnen[1] + ":");
        poäng[1] = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Ange dina poäng för ämnet " + ämnen[2] + ":");
        poäng[2] = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Ange dina poäng för ämnet " + ämnen[3] + ":");
        poäng[3] = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Ange dina poäng för ämnet " + ämnen[4] + ":");
        poäng[4] = Convert.ToInt32(Console.ReadLine());

        
        RäknaPoäng(poäng);

 

    }  

    static void RäknaPoäng(int[] poäng)
    {
        string[] betyg = new string[6];
        for (int x = 0; x < poäng.Length; x++)
        {
        
          if (poäng[x] == 100)
          {
            betyg[x] = "A";
          }
          
          else if(poäng[x] < 100 && poäng[x] > 85)
          {
            betyg[x] = "B";
          }
         
          else if(poäng[x] < 85 && poäng[x] > 70)
          {
            betyg[x] = "C";
          }
          
          else if(poäng[x] < 70 && poäng[x] > 60)
          {
            betyg[x] = "D";
          }
          
          else if(poäng[x] < 60 && poäng[x] > 50)
          {
            betyg[x] = "E";
          }
        
          else if(poäng[x] < 50)
          {
            betyg[x] = "F";
          }

        }
        SkrivUtBetyg(betyg);
        Statistik(poäng, betyg);
    }

           static void SkrivUtBetyg(string[] utSkrift)
           {
            
            Array.ForEach(utSkrift, Console.WriteLine);

            
           }
           

           
        
           
        
        static void Statistik(int[] poängTotal,string[] antalBetyg)
        {
            int total=poängTotal.Sum();
            Console.WriteLine("Totala poäng: " + total);

            var betygAntal = 0;
            
        betygAntal = antalBetyg.Count(c => c == "A");
           
            Console.WriteLine(betygAntal + " stycken A");

        betygAntal = antalBetyg.Count(c => c == "B");
           
            Console.WriteLine(betygAntal + " stycken B");
            
        betygAntal = antalBetyg.Count(c => c == "C");
           
            Console.WriteLine(betygAntal + " stycken C");

        betygAntal = antalBetyg.Count(c => c == "D");
           
            Console.WriteLine(betygAntal + " stycken D");

        betygAntal = antalBetyg.Count(c => c == "E");
           
            Console.WriteLine(betygAntal + " stycken E");

        betygAntal = antalBetyg.Count(c => c == "F");
           
            Console.WriteLine(betygAntal + " stycken F");
         
        }
    
     
    } 
}

   

    