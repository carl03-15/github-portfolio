﻿using System;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;

namespace BMIochBMRKalkylator
{
    class Program
    {
        //Variabler som behövs.
        static void Main(string[] args)
        {
        double vikt = GetVikt();
        double langd = GetLangd();
        //double alder = GetAlder();
        

//Alla resultat för BMI
        double BMI = KalkyleraBMI(vikt, langd);
        Console.WriteLine("Ditt BMI är: " + Math.Round(BMI, 1));
        if (BMI<18.5) 
        {
            Console.WriteLine("Du är underviktig");
        }
        else if (BMI >= 18.5 && BMI <= 25 )
        {
            Console.WriteLine("Du har en sund och normal vikt.");
        }
        else if (BMI >= 25 && BMI <= 30 )
        {
            Console.WriteLine("Du är överviktig");
        }
        else if (BMI >=30 && BMI <= 40 )
        {
            Console.WriteLine("Du är kraftigt överviktig");
        }
        else if (BMI > 40)
        {
            Console.WriteLine("Du är extremt överviktig");
        }


          
//Få vikt från användaren.
    static double GetVikt()
    {
        Console.WriteLine("Ange din vikt i kilogram: ");
        double vikt = double.Parse(Console.ReadLine());
        return vikt;
    }
   
    
        //Få längd från användaren.
    static double GetLangd()
    {
        Console.WriteLine("Ange din längd i centimeter. (Endast mellan 50 till 220cm): ");
        double langd = double.Parse(Console.ReadLine());
        return langd;

         
    }
    
    static double KalkyleraBMI(double vikt, double langd)
    {
        //Gör cm till meter istället för lättare BMI uträkning och return bmi.
        double meterLangd = langd / 100;
        double bmi = vikt / (meterLangd * meterLangd);
        return bmi;
    }
    
     //Få Ålder från användaren.
    //static double GetAlder()
    
    {
        //Console.WriteLine("Ange din ålder: ");
        //double alder = double.Parse(Console.ReadLine());
        //return alder;
    }
    }
    
    //Få kön från användaren.
    //static KalkyleraBMR()
    
      

      //Console.WriteLine("Ange ditt kön (Man/Kvinna): ");
      //string userInput=Console.ReadLine();
      //return KalkyleraBMR;


    }
    }
    
    


