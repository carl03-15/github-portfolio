﻿namespace Väder
{
    public class Stad
    {
        public string Namn { get; set; }
        public int Temp { get; set; }

        public Stad(string namn, int temp)
        {
            Namn = namn;
            Temp = temp;
        }

        public string ToString()
        {
            return $"{Namn} har temperaturen {Temp} grader.";
        }
    }

    public class Program
    {
        // Funktion för linjär sökning
        public static int Linsok(Stad[] stader, int n, int soktemp)
        {
            for (int i = 0; i < n; i++)
            {
                if (stader[i].Temp == soktemp)
                    return i;
            }
            return -1; // Returnera -1 om ingen stad med temperatur hittades
        }

        // Funktion för bubbelsortering
        public static void Bubblesort(Stad[] stader, int n)
        {
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (stader[j].Temp > stader[j + 1].Temp)
                    {
                        // Byt plats på elementen om de är i fel ordning
                        Stad temp = stader[j];
                        stader[j] = stader[j + 1];
                        stader[j + 1] = temp;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            // Skapa ett fält av Stad
            Stad[] stader = new Stad[4];

            for (int i = 0; i < 4; i++)
            {
                Console.Write($"Ange temperaturen för stad {i + 1}: ");
                int temp = int.Parse(Console.ReadLine());
                stader[i] = new Stad($"Stad {i + 1}", temp);
            }

            // Sök efter en stad med specifik temperatur
            Console.Write("Ange temperaturen du söker efter: ");
            int soktemp = int.Parse(Console.ReadLine());
            int index = Linsok(stader, stader.Length, soktemp);
            if (index != -1)
            {
                Console.WriteLine($"Staden med temperaturen {soktemp} finns på index {index}.");
            }
            else
            {
                Console.WriteLine($"Ingen stad med temperaturen {soktemp} hittades.");
            }

            // Sortera städerna efter temperatur (kallast först)
            Bubblesort(stader, stader.Length);

            // Skriv ut de sorterade städerna
            Console.WriteLine("\nStäderna sorterade efter temperatur:");
            foreach (var stad in stader)
            {
                Console.WriteLine(stad.ToString());
            }
        }
    }
}